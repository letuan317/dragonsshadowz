Authors
=======

Flask-OAuthlib is written and maintained by Hsiaoming Yang <me@lepture.com>.

Contributors
------------

People who send patches and suggestions:

.. include:: ../AUTHORS

Find more contributors on Github_.

.. _Github: https://github.com/lepture/flask-oauthlib/contributors
